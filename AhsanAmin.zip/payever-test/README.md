### Setup
Run the following command to run all the containers required to run this project:
``` 
docker-compose up
```

